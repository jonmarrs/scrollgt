"""Fetch all 21 recorded NML sources and compare packed arrays via two parsers.

Run from a configured ScrollGT checkout: python SCRIPT NEW_OUTPUT_DIRECTORY.
Uses the existing update_fiber_ground_truth.py --verify-only CLI and an
independent ElementTree decode. Downloads annotations only; never rewrites data.
"""
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import urllib.request
from urllib.parse import quote
import xml.etree.ElementTree as ET
import numpy as np

root=Path.cwd().resolve()
out=Path(sys.argv[1]).resolve()
if out==root or root in out.parents or out in root.parents:
    raise SystemExit('output must be outside and disjoint from the checkout')
out.mkdir(parents=True,exist_ok=False)
(out/'nml').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[root/'src/scrollgt/fibers/skeleton_io.py', root/'tools/update_fiber_ground_truth.py']
source_hashes={str(p.relative_to(root)):sha(p) for p in sources}
targets=sorted((root/'data').glob('fibers_*'))
assert len(targets)==21, 'all 21 targets required'
before={str(p.relative_to(root)):sha(p) for t in targets for p in (t/'meta.json', t/'skeleton.npz')}


def xml_pack(raw, meta):
    document=ET.fromstring(raw)
    coords,edges,fo,eo,ids,names=[],[],[0],[0],[],[]
    origin=np.asarray(meta['origin_zyx'],dtype=np.float32)
    for thing in document.findall('.//thing'):
        nodes=thing.findall('./nodes/node')
        if not nodes:
            continue
        node_ids=[int(n.attrib['id']) for n in nodes]
        index={n:i for i,n in enumerate(node_ids)}
        xyz=np.array([[float(n.attrib[k]) for k in ('z','y','x')] for n in nodes],dtype=np.float32)-origin
        pairs=[(index[int(e.attrib['source'])],index[int(e.attrib['target'])]) for e in thing.findall('./edges/edge')
               if int(e.attrib['source']) in index and int(e.attrib['target']) in index]
        edge=np.asarray(pairs,dtype=np.int32).reshape(-1,2)+fo[-1]
        coords.append(xyz); edges.append(edge); ids.append(int(thing.attrib['id'])); names.append(thing.get('name',''))
        fo.append(fo[-1]+len(xyz)); eo.append(eo[-1]+len(edge))
    scale=document.find('./parameters/scale')
    if scale is None:
        raise ValueError('NML lacks scale')
    return dict(coords=np.concatenate(coords),edges=np.concatenate(edges),fiber_offsets=np.asarray(fo,np.int64),
                edge_offsets=np.asarray(eo,np.int64),fiber_ids=np.asarray(ids,np.int64),fiber_names=np.asarray(names,dtype=object),
                scale_um=np.array([float(scale.attrib[k]) for k in ('z','y','x')]),origin_zyx=np.array(meta['origin_zyx'],np.int64),
                shape=np.array(meta['shape'],np.int64))


def one(target):
    meta=json.loads((target/'meta.json').read_text())
    nml=meta['ground_truth']['nml']
    assert sha(target/'meta.json')==before[str((target/'meta.json').relative_to(root))]
    assert '/' not in nml['file'] and '/' not in nml['dataset']
    url='https://dl.ash2txt.org/datasets/fiber-skeletons/'+quote(nml['dataset'])+'/nml/'+quote(nml['file'])
    result=dict(target=target.name,url=url,expected_sha256=nml['sha256'],status='FAILED')
    try:
        with urllib.request.urlopen(url,timeout=60) as response:
            raw=response.read(32*1024**2+1)
            result.update(http_status=response.status,final_url=response.geturl(),bytes=len(raw))
        if len(raw)>32*1024**2:
            raise ValueError('annotation exceeds 32 MiB bound')
        result['download_sha256']=hashlib.sha256(raw).hexdigest()
        if result['download_sha256']!=nml['sha256']:
            raise ValueError('upstream annotation hash differs from target provenance')
        path=out/'nml'/nml['file']
        path.write_bytes(raw)
        packed=xml_pack(raw,meta)
        with np.load(target/'skeleton.npz',allow_pickle=True) as shipped:
            differences=sorted(set(shipped.files)^set(packed))
            differences += [k for k in packed if k in shipped.files and not np.array_equal(packed[k],shipped[k])]
        result.update(independent_xml_differences=differences,arrays_checked=len(packed),fibers=len(packed['fiber_ids']),
                      nodes=len(packed['coords']),edges=len(packed['edges']))
        if differences:
            raise ValueError('independent XML decode differs: '+repr(differences))
        command=[sys.executable,str(root/'tools/update_fiber_ground_truth.py'),'--target',str(target),'--nml',str(path),
                 '--dataset',nml['dataset'],'--verify-only']
        run=subprocess.run(command,cwd=root,capture_output=True,text=True,timeout=90)
        log=out/(target.name+'.log')
        log.write_text(run.stdout+run.stderr)
        result.update(command=command,returncode=run.returncode,log=log.name,log_sha256=sha(log))
        if run.returncode or sha(path)!=nml['sha256']:
            raise ValueError('project verification failed or downloaded input changed')
        result['status']='EXACT'
    except Exception as error:
        result['error']=type(error).__name__+': '+str(error)
    print(target.name+': '+result['status'],flush=True)
    return result

with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(one,targets))
unchanged=all(sha(root/p)==h for p,h in {**before,**source_hashes}.items())
record=dict(recorded_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            source_sha256=source_hashes,inputs_sha256=before,harness_sha256=sha(Path(__file__)),
            runtime=dict(python=platform.python_version(),numpy=np.__version__),
            scope='Upstream annotation byte identity and exact packed-array reproduction only. No CT convention, annotation accuracy, model inference or new quality gain.',
            all_sources_and_targets_unchanged=unchanged,
            cases=results,status='EXACT' if unchanged and all(r['status']=='EXACT' for r in results) else 'FAILED')
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],cases=len(results),bytes_downloaded=sum(r.get('bytes',0) for r in results),
                     nodes=sum(r.get('nodes',0) for r in results),edges=sum(r.get('edges',0) for r in results)),indent=2))
if record['status']!='EXACT':
    raise SystemExit(1)
